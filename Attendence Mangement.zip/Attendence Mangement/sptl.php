<?php
session_start();
if(!isset($_SESSION['login']))
{
  header("location:login.php");
  exit;
}
  
else
{
  include "db.php";
  $uname=$_SESSION['uname'];
  $sql="select * from student where email='$uname' ";
  $rst=mysqli_query($con,$sql);
  $row=mysqli_fetch_array($rst);
}


if(isset($_POST["submit"]))
{
  $roll=$_POST['roll'];
  $sem=$_POST['sem'];
  $dept=$_POST['dept'];
  $date=$_POST['date'];
  $qry="insert into atten values('$roll','$sem','$dept','$date')";
  $result=mysqli_query($con,$qry);
  if($result)
  {
    echo"<script> alert('Data Submitted Successfully...!!!')</script>";
  }
}
?>

<!doctype html>
<html lang="en">
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Stuent Portal</title>
    <h1>Hello,<?php echo $row['name'] ?> </h1>
    <h2>To Put Attendence</h2>
    <body>
    <ul class="nav-links">
                <li><a href="index.php">
                  Home</a>
                  </li>
      <style>
 
body{
  display: grid;
  place-items: center;
  text-align: center;
  background-size: cover;
  background-color:lightskyblue;
  background-blend-mode: overlay;
  background-image: url(or.jpeg);

}

        select {
        margin-bottom: 10px;
        margin-top: 10px;
        font-family: cursive, sans-serif;
        outline: 0;
        background: blue;
        color:whitesmoke;
        border: 1px solid crimson;
        padding: 4px;
        border-radius: 9px;

      }
      </style>
    </body>
<form method="post" action="sptl.php">
      <label for="Semester"><b>Roll_No</b></label>
      <input type="number" name="roll">
      <label for="Semester"><b>Semester</b></label>
      <select name="sem" id="sem">
        <option value="select">Select a Semester</option>
        <option value="1st">1st</option>
        <option value="2nd">2nd</option>
        <option value="3rd">3rd</option>
        <option value="4th">4th</option>
        <option value="5th">5th</option>
        <option value="6th">6th</option>
      </select>
      <label for="Department"><b>Department</b></label>
      <select name="dept" id="Dep">
        <option value="select">Select a Department</option>
        <option value="Computer Science">Computer Science</option>
        <option value="Mechanical">Mechanical</option>
        <option value="Electrical">Electrical</option>
        <option value="Civil">Civil</option>
        <option value="Minining">Minining</option>
      </select>
      <input  name="date" type="Date" value="Date"/>
      <input   type="submit" name="submit" value="Submit" />
</form>
 