<!doctype html>
<html lang="en">
  <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Home page</title>
    <style> 
      body{
        margin: 0;
        padding: 0;
        background-color: sandybrown;
      }
      .header{
        height:auto;     
       background-color: ;
      }
      .phone{
        height: 50px;
        background-color: 
      }
      .phone a{
        color: white ;
        display:block;
        text-align: center;
        line-height: 50px;
        font-weight:bold ;
        text-decoration: none;
        letter-spacing: 3px;

      }
      .text{
        height: 50px;
        background-color: 
      }
      .text marquee{
        color: white;
        font-size: 20px;
        line-height: 50px;
        font-style: italic;
      }
      .icon{
        height: 50px;
        background-color: 
      }
      .icon ol {
        text-align: center ;
     }
      .icon ol li{
        display: inline-block;
      }
      .icon ol li a{
        color: white;
        text-decoration: none;
        line-height: 50px;
        margin-left: 3px;
      }
      .fa-facebook{
        color: white;
        background-color: blue;
        padding: 3px 5px;
        border-radius: 3px;
      }
      .fa-whatsapp{
        color: white;
        background-color: green;
        padding: 3px 5px;
        border-radius: 3px;
     }
     .fa-twitter{
         color: white;
        background-color: yellow;
        padding: 3px 5px;
        border-radius: 3px;
      }
      .fa-instagram{
        color: white;
        background-color: pink;
        padding: 3px 5px;
        border-radius: 3px;
      }
      .menu{
        height: 80px;
        background-color: ;
      }
      .logo{
        height: 80px;
        background-color: ;
      }
      .mbutton{
        height: 80px;
        background-color:babypink;
      }
      .search{
        height: 80px;
        background-color: babypink;
      }
      .mbutton ol{
        text-align: center;

      }
      .mbutton ol li{
        display: inline-block;

      }
      .mbutton ol li a{
        color: white;
      line-height: 80px;
      background-color:blue;
      margin-left: 5px;
      text-decoration:none;
      padding: 3px 5px;
    }
    .mbutton ol li a: hover{
      color: yellow;
      background-color: bisque;

    }
    </style>
  </head>
  <body background="or.jpeg" style="background-size: cover">
    <div class="container-fluid header">
      <div class="row">
      <div class="col-12 col-md-4 col sm-12 phone">
        <a href="tel:+919635395137"></a>
        
      </div>
      <div class="col-12 col-md-4 col-sm-12 text">
        <marquee scroll amount="10">welcome To Attendence Manegement System</marquee>
        
      </div>
      <div class="col-12 col-md-4 col-sm-12 icon">
        <ol>
          <li><a href="https:\\www.facebook.com">
          <i class="fa fa-facebook" aria-hidden="true"></i></a></li>
          <li><a href="https:\\www.whatsapp.com">
          <i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
          <li><a href="https:\\www.twitter.com">
          <i class="fa fa-twitter" aria-hidden="true"></i></a></li>
          <li><a href="https:\\www.instagram.com"><i class="fa fa-instagram" aria-hidden="true"></i>
          </a></li>
          

          

          
          
        </ol>
       </div> 
          
        
      </div>

      
    </div>
    <div class="container-fluid menu">
      <div class="row">
        <div class="col-12 col-md-4 col-sm-12 logo">
          
        </div>

        </div>
        <div class="col-12 col-md-4 col-sm-12 search">
          
        </div>
      </div>
      <h1></h1>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3653.8388975357875!2d87.01215597418718!3d23.681718591411766!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39f719017f7bf3a5%3A0x73d00829fab18015!2sAsansol%20Institute%20Of%20Engineering%20And%20Management-Polytechnic!5e0!3m2!1sen!2sin!4v1707324622002!5m2!1sen!2sin" width="600" height="550" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>

      
  

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<input type="date">